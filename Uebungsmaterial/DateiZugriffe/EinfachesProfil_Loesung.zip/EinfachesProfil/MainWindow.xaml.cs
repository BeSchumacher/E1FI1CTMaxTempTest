﻿using Microsoft.Win32;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EinfachesProfil
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        /****** Hinweis *****************
         * Die Daten sollen in der Datei
         * kommasepariert in einer Zeile liegen
         * Beispiel: Max Mustermann,31,RaZ0r,Medic
         ******************************/

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //Speichern
            var fileContent = string.Empty;
            var filePath = string.Empty;

            SaveFileDialog saveFileDialog = new SaveFileDialog();
            try
            {
                saveFileDialog.InitialDirectory = "C:\\Users\\Ge\\source\\repos\\EinfachesProfil\\EinfachesProfil\\";
                saveFileDialog.Filter = "csv files (*.csv)|*.csv|All files (*.*)|*.*";
                saveFileDialog.FilterIndex = 2;
                saveFileDialog.RestoreDirectory = true;

                string headerString = "Name,Alter,Nickname,Klasse";
                string resultString = txb_name.Text + "," + txb_alter.Text + "," + txb_nickname.Text + "," + txb_klasse.Text;
                string[] createText = { resultString };

                if (saveFileDialog.ShowDialog() == true)
                {
                    File.WriteAllLines(saveFileDialog.FileName, createText);
                }
                    
                    
            }
            catch (Exception ex)
            {
                throw new Exception("Datei kann nicht geladen werden.");
            }

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //Laden
            var profilHeaderContent = string.Empty;
            var profilContent = string.Empty;
            var filePath = string.Empty;

            OpenFileDialog openFileDialog = new OpenFileDialog();
            try
            {
                openFileDialog.InitialDirectory = "C:\\Users\\Ge\\source\\repos\\EinfachesProfil\\EinfachesProfil\\";
                openFileDialog.Filter = "csv files (*.csv)|*.csv|All files (*.*)|*.*";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == true) //DialogResult.OK
                {
                    //Get the path of specified file
                    filePath = openFileDialog.FileName;

                    //Read the contents of the file into a stream
                    var fileStream = openFileDialog.OpenFile();

                    StreamReader reader = new StreamReader(fileStream);
                    try
                    {
                        profilHeaderContent = reader.ReadLine();
                        // erkenne, ob die Datei einen Header besitzt
                        if (profilHeaderContent.Split(',')[0] == "name")
                        {
                            profilContent = reader.ReadLine();
                        }
                        else
                        {
                            profilContent = profilHeaderContent;
                            profilHeaderContent = "";
                        }
                    }
                    catch (Exception ex)
                    {
                        throw new Exception("Datei kann nicht gelesen werden");
                    }

                    string[] profilEigenschaften = profilContent.Split(",");
                    if (profilEigenschaften.Length == 4)
                    {
                        txb_name.Text = profilEigenschaften[0];
                        txb_alter.Text = profilEigenschaften[1];
                        txb_nickname.Text = profilEigenschaften[2];
                        txb_klasse.Text = profilEigenschaften[3];
                    }

                }
            }
            catch (Exception ex)
            {
                throw new Exception("Datei kann nicht geladen werden.");
            }
        }
    }
}