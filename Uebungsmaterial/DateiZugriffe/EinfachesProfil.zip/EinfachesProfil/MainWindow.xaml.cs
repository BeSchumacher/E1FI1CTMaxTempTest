﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EinfachesProfil
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        /****** Hinweis *****************
         * Die Daten sollen in der Datei
         * kommasepariert in einer Zeile liegen
         * Beispiel: Max Mustermann,31,RaZ0r,Medic
         ******************************/

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //Speichern
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //Laden
        }
    }
}