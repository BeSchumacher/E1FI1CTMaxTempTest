﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SystemInternalsWPF
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnGetInfo_Click(object sender, RoutedEventArgs e)
        {
            string eingabe, ausgabe;
            eingabe = cboAuswahl.Text;

            switch (eingabe)
            {
                case "Systembenutzer":
                    ausgabe = Systeminternals.GetUserInfo();
                    break;
                case "Systemlaufzeit":
                    ausgabe = Systeminternals.GetUpTime();
                    break;
                case "Freigaben":
                    ausgabe = Systeminternals.GetAllShares();
                    break;
                case "Seriennummer":
                    ausgabe = Systeminternals.GetSerialnumber();
                    break;
                case "DriveInfo":
                    ausgabe = Systeminternals.GetStorageInfo();
                    break;
                default:
                    ausgabe = "Bitte eine vorgegebene Auswahl treffen...";
                    break;
            }

            txbAusgabe.Text = ausgabe;
        }
    }
}
