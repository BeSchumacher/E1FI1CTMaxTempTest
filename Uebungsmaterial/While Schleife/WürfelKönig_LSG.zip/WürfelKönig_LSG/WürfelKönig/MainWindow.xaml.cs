﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WürfelKönig
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            lblGut.Visibility = Visibility.Hidden;
            lblSchlecht.Visibility = Visibility.Hidden;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            lblGut.Visibility = Visibility.Hidden;
            lblSchlecht.Visibility = Visibility.Hidden;

            Random rnd = new Random();
            int zahlZuWuerfeln = Convert.ToInt32(txtZahlZuWuerfeln.Text);
            int geschaetzteAnzahlWuerfe = Convert.ToInt32(txtAnzahlWuerfeGeraten.Text); ;
            int randZahl = 0;
            int anzahlWuerfe = 0;

            while (zahlZuWuerfeln != randZahl)
            {
                randZahl = rnd.Next(1, 7);
                anzahlWuerfe++;
            }

            lblComputerVersuche.Content = Convert.ToString(anzahlWuerfe);

            if (geschaetzteAnzahlWuerfe == anzahlWuerfe)
            {
                lblGut.Visibility = Visibility.Visible;
            }
            else
            {
                lblSchlecht.Visibility = Visibility.Visible;
            }

        }
    }
}
