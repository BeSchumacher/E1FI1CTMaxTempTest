﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Schuldenrechner
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnBerechne_Click(object sender, EventArgs e)
        {
            double betrag = Convert.ToDouble(txtBetrag.Text);
            double rate = Convert.ToDouble(txtMRate.Text);
            
            while ()
            {
               
                txtTilgung.AppendText(Convert.ToString(betrag));


            }
        }
    }
}
