﻿namespace Schuldenrechner
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtBetrag = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtZinsen = new System.Windows.Forms.TextBox();
            this.txtListeZinsen = new System.Windows.Forms.TextBox();
            this.btnBerechne = new System.Windows.Forms.Button();
            this.txtTilgung = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtMRate = new System.Windows.Forms.TextBox();
            this.lblJahre = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtBetrag
            // 
            this.txtBetrag.Location = new System.Drawing.Point(146, 23);
            this.txtBetrag.Name = "txtBetrag";
            this.txtBetrag.Size = new System.Drawing.Size(126, 20);
            this.txtBetrag.TabIndex = 0;
            this.txtBetrag.Text = "100000";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Aufgenommener Betrag:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Zinsen p.a.:";
            // 
            // txtZinsen
            // 
            this.txtZinsen.Location = new System.Drawing.Point(146, 51);
            this.txtZinsen.Name = "txtZinsen";
            this.txtZinsen.Size = new System.Drawing.Size(55, 20);
            this.txtZinsen.TabIndex = 0;
            this.txtZinsen.Text = "3,6";
            // 
            // txtListeZinsen
            // 
            this.txtListeZinsen.Location = new System.Drawing.Point(21, 237);
            this.txtListeZinsen.Multiline = true;
            this.txtListeZinsen.Name = "txtListeZinsen";
            this.txtListeZinsen.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtListeZinsen.Size = new System.Drawing.Size(111, 216);
            this.txtListeZinsen.TabIndex = 2;
            // 
            // btnBerechne
            // 
            this.btnBerechne.Location = new System.Drawing.Point(15, 109);
            this.btnBerechne.Name = "btnBerechne";
            this.btnBerechne.Size = new System.Drawing.Size(257, 38);
            this.btnBerechne.TabIndex = 3;
            this.btnBerechne.Text = "Berechne Verlauf";
            this.btnBerechne.UseVisualStyleBackColor = true;
            this.btnBerechne.Click += new System.EventHandler(this.btnBerechne_Click);
            // 
            // txtTilgung
            // 
            this.txtTilgung.Location = new System.Drawing.Point(161, 237);
            this.txtTilgung.Multiline = true;
            this.txtTilgung.Name = "txtTilgung";
            this.txtTilgung.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtTilgung.Size = new System.Drawing.Size(111, 216);
            this.txtTilgung.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 221);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Gezahlte Zinsen";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(159, 221);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Tilgung";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 84);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(121, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Monatl. Abzahlungsrate:";
            // 
            // txtMRate
            // 
            this.txtMRate.Location = new System.Drawing.Point(145, 81);
            this.txtMRate.Name = "txtMRate";
            this.txtMRate.Size = new System.Drawing.Size(127, 20);
            this.txtMRate.TabIndex = 0;
            this.txtMRate.Text = "700";
            // 
            // lblJahre
            // 
            this.lblJahre.AutoSize = true;
            this.lblJahre.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJahre.Location = new System.Drawing.Point(129, 173);
            this.lblJahre.Name = "lblJahre";
            this.lblJahre.Size = new System.Drawing.Size(20, 24);
            this.lblJahre.TabIndex = 1;
            this.lblJahre.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 466);
            this.Controls.Add(this.btnBerechne);
            this.Controls.Add(this.txtTilgung);
            this.Controls.Add(this.txtListeZinsen);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblJahre);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtMRate);
            this.Controls.Add(this.txtZinsen);
            this.Controls.Add(this.txtBetrag);
            this.Name = "Form1";
            this.Text = "Schuldenrechner";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtBetrag;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtZinsen;
        private System.Windows.Forms.TextBox txtListeZinsen;
        private System.Windows.Forms.Button btnBerechne;
        private System.Windows.Forms.TextBox txtTilgung;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtMRate;
        private System.Windows.Forms.Label lblJahre;
    }
}

