﻿namespace Sparzielrechner
{
    partial class frmRechner
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpEingabe = new System.Windows.Forms.GroupBox();
            this.txtZielguthaben = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblStartguthaben = new System.Windows.Forms.Label();
            this.txtAnfGuthaben = new System.Windows.Forms.TextBox();
            this.txtZinsen = new System.Windows.Forms.TextBox();
            this.lblZinsen = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbllz = new System.Windows.Forms.Label();
            this.txtLaufzeit = new System.Windows.Forms.TextBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.grpEingabe.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpEingabe
            // 
            this.grpEingabe.Controls.Add(this.lblStartguthaben);
            this.grpEingabe.Controls.Add(this.lblZinsen);
            this.grpEingabe.Controls.Add(this.label1);
            this.grpEingabe.Controls.Add(this.txtAnfGuthaben);
            this.grpEingabe.Controls.Add(this.txtZinsen);
            this.grpEingabe.Controls.Add(this.txtZielguthaben);
            this.grpEingabe.Location = new System.Drawing.Point(17, 13);
            this.grpEingabe.Name = "grpEingabe";
            this.grpEingabe.Size = new System.Drawing.Size(248, 111);
            this.grpEingabe.TabIndex = 0;
            this.grpEingabe.TabStop = false;
            this.grpEingabe.Text = "Eingabe";
            // 
            // txtZielguthaben
            // 
            this.txtZielguthaben.Location = new System.Drawing.Point(113, 45);
            this.txtZielguthaben.Name = "txtZielguthaben";
            this.txtZielguthaben.Size = new System.Drawing.Size(100, 20);
            this.txtZielguthaben.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Zielguthaben:";
            // 
            // lblStartguthaben
            // 
            this.lblStartguthaben.AutoSize = true;
            this.lblStartguthaben.Location = new System.Drawing.Point(19, 16);
            this.lblStartguthaben.Name = "lblStartguthaben";
            this.lblStartguthaben.Size = new System.Drawing.Size(94, 13);
            this.lblStartguthaben.TabIndex = 1;
            this.lblStartguthaben.Text = "Anfangsguthaben:";
            // 
            // txtAnfGuthaben
            // 
            this.txtAnfGuthaben.Location = new System.Drawing.Point(113, 13);
            this.txtAnfGuthaben.Name = "txtAnfGuthaben";
            this.txtAnfGuthaben.Size = new System.Drawing.Size(100, 20);
            this.txtAnfGuthaben.TabIndex = 0;
            // 
            // txtZinsen
            // 
            this.txtZinsen.Location = new System.Drawing.Point(113, 71);
            this.txtZinsen.Name = "txtZinsen";
            this.txtZinsen.Size = new System.Drawing.Size(100, 20);
            this.txtZinsen.TabIndex = 0;
            // 
            // lblZinsen
            // 
            this.lblZinsen.AutoSize = true;
            this.lblZinsen.Location = new System.Drawing.Point(19, 74);
            this.lblZinsen.Name = "lblZinsen";
            this.lblZinsen.Size = new System.Drawing.Size(42, 13);
            this.lblZinsen.TabIndex = 1;
            this.lblZinsen.Text = "Zinsen:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtLaufzeit);
            this.groupBox1.Controls.Add(this.lbllz);
            this.groupBox1.Location = new System.Drawing.Point(17, 204);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(247, 97);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Ausgabe";
            // 
            // lbllz
            // 
            this.lbllz.AutoSize = true;
            this.lbllz.Location = new System.Drawing.Point(10, 44);
            this.lbllz.Name = "lbllz";
            this.lbllz.Size = new System.Drawing.Size(47, 13);
            this.lbllz.TabIndex = 0;
            this.lbllz.Text = "Laufzeit:";
            // 
            // txtLaufzeit
            // 
            this.txtLaufzeit.Location = new System.Drawing.Point(85, 41);
            this.txtLaufzeit.Name = "txtLaufzeit";
            this.txtLaufzeit.Size = new System.Drawing.Size(100, 20);
            this.txtLaufzeit.TabIndex = 1;
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(17, 149);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(247, 29);
            this.btnStart.TabIndex = 2;
            this.btnStart.Text = "Start der Berechnung";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // frmRechner
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 328);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.grpEingabe);
            this.Name = "frmRechner";
            this.Text = "Sparzielrechner";
            this.grpEingabe.ResumeLayout(false);
            this.grpEingabe.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpEingabe;
        private System.Windows.Forms.Label lblStartguthaben;
        private System.Windows.Forms.Label lblZinsen;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAnfGuthaben;
        private System.Windows.Forms.TextBox txtZinsen;
        private System.Windows.Forms.TextBox txtZielguthaben;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtLaufzeit;
        private System.Windows.Forms.Label lbllz;
        private System.Windows.Forms.Button btnStart;
    }
}

