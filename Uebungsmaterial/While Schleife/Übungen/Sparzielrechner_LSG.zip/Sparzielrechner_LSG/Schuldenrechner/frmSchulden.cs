﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Schuldenrechner
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnBerechne_Click(object sender, EventArgs e)
        {
            double betrag = Convert.ToDouble(txtBetrag.Text);
            double zinsSatz = Convert.ToDouble(txtZinsen.Text);
            double monatlRate = Convert.ToDouble(txtMRate.Text);

            double betragNeu = 0.0;
            double zinsenJahr = 0.0;
            double tilgung = 0.0;
            int jahre = 0;

            txtListeZinsen.Clear();
            txtTilgung.Clear();

            while (betrag > 0)
            {
                jahre++;
                zinsenJahr = betrag * ((zinsSatz)/100);
                tilgung = monatlRate * 12 - zinsenJahr; 
                betragNeu = betrag - tilgung;
                betrag = betragNeu;

                txtTilgungZusammen.AppendText($"{monatlRate * 12} : {zinsenJahr:0.#} " + Environment.NewLine);
                txtListeZinsen.AppendText($"{zinsenJahr:0.#}" + Environment.NewLine);
                txtTilgung.AppendText($"{betrag:0.#}"  + Environment.NewLine);


            }
            lblJahre.Text = $"{jahre}";
        }
    }
}
